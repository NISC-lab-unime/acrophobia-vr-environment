# acrophobia-vr-environment
VR environment for acrophobia exposure therapy built in Unity 6 (URP mode) using XR Interaction Toolkit, with dynamic SFX and biofeedback integration for adaptive exposure.
